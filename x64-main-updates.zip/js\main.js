$(document).ready(function() {
    // Эффект печатания для логотипа
    function initTypingEffect() {
        const typingElements = document.querySelectorAll('.typing-effect');
        
        typingElements.forEach(function(element) {
            const text = element.getAttribute('data-text');
            
            // Если на странице есть элементы с эффектом печатания
            if (text) {
                // Сначала очищаем текст
                element.textContent = '';
                
                let isTyping = true;
                let charIndex = 0;
                
                // Добавляем класс для отображения курсора
                element.classList.add('cursor-active');
                
                function typeAndErase() {
                    // Если печатаем текст вперед
                    if (isTyping) {
                        if (charIndex < text.length) {
                            element.textContent += text.charAt(charIndex);
                            charIndex++;
                            setTimeout(typeAndErase, 150);
                        } else {
                            // Когда текст напечатан полностью, делаем паузу перед стиранием
                            isTyping = false;
                            setTimeout(typeAndErase, 1500);
                        }
                    } 
                    // Если стираем текст
                    else {
                        if (charIndex > 0) {
                            charIndex--;
                            element.textContent = text.substring(0, charIndex);
                            setTimeout(typeAndErase, 100);
                        } else {
                            // Когда текст полностью стерт, удаляем курсор и делаем паузу
                            element.classList.remove('cursor-active');
                            
                            // Делаем паузу и перезапускаем весь цикл
                            setTimeout(function() {
                                // Перед началом нового цикла активируем курсор
                                element.classList.add('cursor-active');
                                isTyping = true;
                                typeAndErase();
                            }, 1000);
                        }
                    }
                }
                
                // Запускаем анимацию с небольшой задержкой
                setTimeout(typeAndErase, 500);
            }
        });
    }
    
    // Запускаем эффект печатания
    initTypingEffect();
    
    // Мобильное меню
    $('.mobile-menu-toggle').on('click', function() {
        $('.mobile-menu').addClass('active');
        $('body').addClass('no-scroll');
    });
    
    $('.mobile-menu-close').on('click', function() {
        $('.mobile-menu').removeClass('active');
        $('body').removeClass('no-scroll');
    });
    
    $('.has-submenu > a').on('click', function(e) {
        e.preventDefault();
        $(this).parent().toggleClass('active');
        $(this).next('.mobile-submenu').slideToggle(300);
    });
    
    // Улучшенный слайдер на главной 
    let currentSlide = 0;
    const slides = $('.slide');
    const slidesCount = slides.length;
    let slideInterval;
    let touchStartX = 0;
    let touchEndX = 0;
    
    // Инициализация слайдера
    function initSlider() {
        if (slidesCount > 0) {
            startSlideTimer();
            
            // Клик по стрелкам с улучшенной обработкой событий
            $('.slider-arrow.prev').on('click touchend', function(e) {
                e.preventDefault();
                e.stopPropagation();
                prevSlide();
                return false;
            });
            
            $('.slider-arrow.next').on('click touchend', function(e) {
                e.preventDefault();
                e.stopPropagation();
                nextSlide();
                return false;
            });
            
            // Клик по точкам
            $('.dot').on('click touchend', function(e) {
                e.preventDefault();
                goToSlide($(this).data('slide'));
            });
            
            // Улучшенная поддержка свайпов
            initTouchEvents();
            
            // Пауза при наведении на слайдер
            $('.hero-slider').on('mouseenter', function() {
                clearInterval(slideInterval);
            }).on('mouseleave', function() {
                startSlideTimer();
            });
        }
    }
    
    // Функция для инициализации обработки свайпов
    function initTouchEvents() {
        const sliderElement = $('.hero-slider')[0];
        
        if (!sliderElement) return;
        
        // Обработка начала касания
        sliderElement.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
            // Останавливаем автоматическое переключение при касании
            clearInterval(slideInterval);
        }, { passive: true });
        
        // Обработка окончания касания
        sliderElement.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
            // Возобновляем автоматическое переключение после касания
            startSlideTimer();
        }, { passive: true });
    }
    
    // Обработка свайпа
    function handleSwipe() {
        const minSwipeDistance = 50; // Минимальное расстояние для регистрации свайпа
        
        // Определяем направление свайпа
        if (touchEndX < touchStartX - minSwipeDistance) {
            // Свайп влево -> следующий слайд
            nextSlide();
        } else if (touchEndX > touchStartX + minSwipeDistance) {
            // Свайп вправо -> предыдущий слайд
            prevSlide();
        }
    }
    
    // Запуск таймера для автоматического переключения слайдов
    function startSlideTimer() {
        clearInterval(slideInterval);
        slideInterval = setInterval(function() {
            nextSlide();
        }, 5000);
    }
    
    // Переход к предыдущему слайду
    function prevSlide() {
        goToSlide(currentSlide - 1);
    }
    
    // Переход к следующему слайду
    function nextSlide() {
        goToSlide(currentSlide + 1);
    }
    
    // Переход к конкретному слайду
    function goToSlide(index) {
        // Сначала останавливаем таймер
        clearInterval(slideInterval);
        
        // Проверка границ
        if (index < 0) {
            index = slidesCount - 1;
        } else if (index >= slidesCount) {
            index = 0;
        }
        
        // Если это не текущий слайд
        if (index !== currentSlide) {
            // Убираем активные классы
            $('.slide').removeClass('active');
            $('.dot').removeClass('active');
            
            // Устанавливаем активные классы
            $(slides[index]).addClass('active');
            $(`.dot[data-slide="${index}"]`).addClass('active');
            
            // Обновляем текущий слайд
            currentSlide = index;
        }
        
        // Перезапускаем таймер
        startSlideTimer();
    }
    
    // Инициализируем слайдер
    if ($('.hero-slider').length > 0) {
        initSlider();
    }
    
    // Фильтрация товаров по категориям
    $('.tab').on('click', function() {
        const category = $(this).data('category');
        
        // Переключение активного таба
        $('.tab').removeClass('active');
        $(this).addClass('active');
        
        // Фильтрация товаров
        if (category === 'all') {
            $('.products-grid .col-lg-3, .products-grid .col-xl-4, .products-grid .col-md-6').show();
        } else {
            $('.products-grid .col-lg-3, .products-grid .col-xl-4, .products-grid .col-md-6').hide();
            $(`.products-grid .product-card[data-category*="${category}"]`).closest('.col-lg-3, .col-xl-4, .col-md-6').show();
        }
    });
    
    // Добавление в избранное
    $(document).on('click', '.wishlist-btn', function(e) {
        e.preventDefault();
        $(this).toggleClass('active');
        
        // Здесь может быть AJAX запрос для добавления товара в избранное
        const isActive = $(this).hasClass('active');
        const productCard = $(this).closest('.product-card');
        const productTitle = productCard.find('.product-title a').text();
        
        if (isActive) {
            showNotification(`"${productTitle}" добавлен в избранное`);
        } else {
            showNotification(`"${productTitle}" удален из избранного`);
        }
    });
    
    // Быстрый просмотр товара - обработка уже реализована в phone-case-effects.js
    // Эта функция удалена, чтобы избежать конфликта с 3D-моделью
    
    // Добавление в корзину - реализация перенесена в db.js
    /* $(document).on('click', '.btn-add-to-cart', function(e) {
        // Реализация отключена, так как обработка выполняется в db.js
    }); */
    
    // Кнопка "Наверх" с поддержкой Bootstrap
    const backToTop = $('.back-to-top');
    
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 300) {
            backToTop.fadeIn(300);
        } else {
            backToTop.fadeOut(300);
        }
    });
    
    backToTop.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, 500);
        return false;
    });
    
    // Уведомления с Bootstrap Toast
    function showNotification(message) {
        // Проверяем, есть ли уже контейнер для уведомлений
        if ($('.toast-container').length === 0) {
            $('body').append('<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 9999;"></div>');
        }
        
        // Создаем уведомление в стиле Bootstrap
        const toastId = 'toast-' + Date.now();
        const toastHtml = `
        <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <strong class="me-auto">Уведомление</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>`;
        
        $('.toast-container').append(toastHtml);
        
        // Инициализируем и показываем Toast
        const toastElement = document.getElementById(toastId);
        const toastInstance = new bootstrap.Toast(toastElement, {
            autohide: true,
            delay: 3000
        });
        
        toastInstance.show();
        
        // Удаляем элемент после закрытия
        $(toastElement).on('hidden.bs.toast', function () {
            $(this).remove();
        });
    }
    
    // Обработчики для кнопок изменения количества (плюс и минус)
    $(document).on('click', '.quantity-btn.plus', function() {
        const input = $(this).siblings('.quantity-input');
        const currentValue = parseInt(input.val());
        input.val(currentValue + 1);
    });
    
    $(document).on('click', '.quantity-btn.minus', function() {
        const input = $(this).siblings('.quantity-input');
        const currentValue = parseInt(input.val());
        if (currentValue > 1) {
            input.val(currentValue - 1);
        }
    });
    
    // Инициализация компонентов Bootstrap
    
    // Tooltips (подсказки)
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Popovers (всплывающие окна)
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });
}); 