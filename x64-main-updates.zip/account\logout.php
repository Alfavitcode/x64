<?php
// Начинаем сессию
session_start();

// Очищаем все переменные сессии
$_SESSION = array();

// Уничтожаем сессию
session_destroy();

// Перенаправляем на главную страницу
header("Location: /");
exit;
?> 