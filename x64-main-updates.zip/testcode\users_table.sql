-- Удаление существующей таблицы пользователей, если она существует
DROP TABLE IF EXISTS `users`;

-- Создание новой таблицы пользователей с обновленной структурой
CREATE TABLE `users` (
    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(255) NOT NULL COMMENT 'ФИО пользователя (отчество не обязательно)',
    `email` VARCHAR(255) NOT NULL UNIQUE COMMENT 'Электронная почта пользователя',
    `phone` VARCHAR(20) NOT NULL COMMENT 'Номер телефона пользователя',
    `login` VARCHAR(255) NOT NULL UNIQUE COMMENT 'Логин пользователя для входа в систему',
    `password` VARCHAR(255) NOT NULL COMMENT 'Хешированный пароль пользователя',
    `role` VARCHAR(20) NOT NULL DEFAULT 'user' COMMENT 'Роль пользователя (по умолчанию "user")'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Таблица пользователей интернет-магазина';

-- Образец добавления тестового пользователя-администратора (пароль: admin123)
-- INSERT INTO `users` (`fullname`, `email`, `phone`, `login`, `password`, `role`) VALUES
-- ('Администратор Сайта', 'admin@example.com', '+7 (999) 999-99-99', 'admin', '$2y$10$9QS1rZ7M1VH7X3iLMWBUzu7U2ZhEhiYHgGIoi7uw/KQGBVa8AqNG2', 'admin');

-- Образец добавления тестового обычного пользователя (пароль: user123)
-- INSERT INTO `users` (`fullname`, `email`, `phone`, `login`, `password`, `role`) VALUES
-- ('Иван Иванов', 'user@example.com', '+7 (888) 888-88-88', 'user', '$2y$10$o4yF3aBOFn5oT1yD6QTbdO.lRMUGlH00bQNJQrmsVQEBayBOxAK2.', 'user'); 