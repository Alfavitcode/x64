/**
 * JavaScript-функции для работы с базой данных через AJAX
 */

// Корзина
const Cart = {
    /**
     * Добавление товара в корзину
     * @param {number} productId ID товара
     * @param {number} quantity Количество
     * @returns {Promise}
     */
    addToCart: function(productId, quantity = 1) {
        return $.ajax({
            url: '/ajax/add_to_cart.php',
            type: 'POST',
            dataType: 'json',
            data: {
                product_id: productId,
                quantity: quantity
            }
        });
    },
    
    /**
     * Удаление товара из корзины
     * @param {number} cartItemId ID элемента корзины
     * @returns {Promise}
     */
    removeFromCart: function(cartItemId) {
        return $.ajax({
            url: '/ajax/cart.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'remove',
                cart_item_id: cartItemId
            }
        });
    },
    
    /**
     * Обновление количества товара в корзине
     * @param {number} cartItemId ID элемента корзины
     * @param {number} quantity Новое количество
     * @returns {Promise}
     */
    updateQuantity: function(cartItemId, quantity) {
        return $.ajax({
            url: '/ajax/cart.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'update',
                cart_item_id: cartItemId,
                quantity: quantity
            }
        });
    },
    
    /**
     * Получение содержимого корзины
     * @returns {Promise}
     */
    getCartContents: function() {
        return $.ajax({
            url: '/ajax/cart.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'get'
            }
        });
    }
};

// Избранное
const Wishlist = {
    /**
     * Добавление товара в избранное
     * @param {number} productId ID товара
     * @returns {Promise}
     */
    addToWishlist: function(productId) {
        return $.ajax({
            url: '/ajax/wishlist.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'add',
                product_id: productId
            }
        });
    },
    
    /**
     * Удаление товара из избранного
     * @param {number} wishlistItemId ID элемента избранного
     * @returns {Promise}
     */
    removeFromWishlist: function(wishlistItemId) {
        return $.ajax({
            url: '/ajax/wishlist.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'remove',
                wishlist_item_id: wishlistItemId
            }
        });
    },
    
    /**
     * Проверка, находится ли товар в избранном
     * @param {number} productId ID товара
     * @returns {Promise}
     */
    isInWishlist: function(productId) {
        return $.ajax({
            url: '/ajax/wishlist.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'check',
                product_id: productId
            }
        });
    },
    
    /**
     * Получение списка избранных товаров
     * @returns {Promise}
     */
    getWishlistContents: function() {
        return $.ajax({
            url: '/ajax/wishlist.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'get'
            }
        });
    }
};

// Товары
const Products = {
    /**
     * Получение товаров по категории
     * @param {string} category Категория товаров
     * @param {Object} filters Фильтры
     * @param {string} sort Сортировка
     * @param {number} page Страница
     * @param {number} limit Лимит товаров на странице
     * @returns {Promise}
     */
    getProductsByCategory: function(category, filters = {}, sort = 'popular', page = 1, limit = 12) {
        return $.ajax({
            url: '/ajax/products.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'get_by_category',
                category: category,
                filters: JSON.stringify(filters),
                sort: sort,
                page: page,
                limit: limit
            }
        });
    },
    
    /**
     * Поиск товаров
     * @param {string} query Поисковый запрос
     * @param {Object} filters Фильтры
     * @param {string} sort Сортировка
     * @param {number} page Страница
     * @param {number} limit Лимит товаров на странице
     * @returns {Promise}
     */
    searchProducts: function(query, filters = {}, sort = 'popular', page = 1, limit = 12) {
        return $.ajax({
            url: '/ajax/products.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'search',
                query: query,
                filters: JSON.stringify(filters),
                sort: sort,
                page: page,
                limit: limit
            }
        });
    },
    
    /**
     * Получение информации о товаре
     * @param {number} productId ID товара
     * @returns {Promise}
     */
    getProductDetails: function(productId) {
        return $.ajax({
            url: '/ajax/products.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'get_details',
                product_id: productId
            }
        });
    },
    
    /**
     * Получение похожих товаров
     * @param {number} productId ID товара
     * @param {number} limit Лимит товаров
     * @returns {Promise}
     */
    getRelatedProducts: function(productId, limit = 4) {
        return $.ajax({
            url: '/ajax/products.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'get_related',
                product_id: productId,
                limit: limit
            }
        });
    }
};

// Отзывы
const Reviews = {
    /**
     * Получение отзывов о товаре
     * @param {number} productId ID товара
     * @param {number} page Страница
     * @param {number} limit Лимит отзывов на странице
     * @returns {Promise}
     */
    getProductReviews: function(productId, page = 1, limit = 5) {
        return $.ajax({
            url: '/ajax/reviews.php',
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'get',
                product_id: productId,
                page: page,
                limit: limit
            }
        });
    },
    
    /**
     * Добавление отзыва о товаре
     * @param {number} productId ID товара
     * @param {number} rating Рейтинг
     * @param {string} name Имя пользователя
     * @param {string} email Email пользователя
     * @param {string} text Текст отзыва
     * @returns {Promise}
     */
    addProductReview: function(productId, rating, name, email, text) {
        return $.ajax({
            url: '/ajax/reviews.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'add',
                product_id: productId,
                rating: rating,
                name: name,
                email: email,
                text: text
            }
        });
    }
};

// Инициализация обработчиков событий
$(document).ready(function() {
    // Добавление товара в корзину
    $(document).on('click', '.btn-add-to-cart', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const productId = $button.data('product-id');
        let quantity = 1;
        
        // Если товар уже добавляется, прерываем выполнение
        if ($button.hasClass('adding') || $button.hasClass('added') || $button.hasClass('disabled')) {
            return;
        }
        
        // Если есть поле с количеством
        const quantityInput = $('.quantity-input');
        if (quantityInput.length) {
            quantity = parseInt(quantityInput.val());
        }
        
        // Анимация добавления в корзину
        $button.addClass('adding').prop('disabled', true);
        
        Cart.addToCart(productId, quantity)
            .done(function(response) {
                $button.removeClass('adding');
                
                if (response.success) {
                    // Обновляем счетчик корзины
                    $('.cart-count').text(response.cart_count);
                    
                    // Показываем анимацию успешного добавления
                    $button.addClass('added');
                    setTimeout(function() {
                        $button.removeClass('added').prop('disabled', false);
                    }, 1500);
                    
                    // Определяем название товара для уведомления
                    let productTitle = 'Товар';
                    const productCard = $button.closest('.product-card');
                    if (productCard.length) {
                        const titleElem = productCard.find('.product-title a');
                        if (titleElem.length) {
                            productTitle = titleElem.text();
                        }
                    }
                    
                    // Показываем уведомление
                    showNotification(`"${productTitle}" ${response.message}`);
                } else {
                    $button.prop('disabled', false);
                    showNotification(response.message || 'Произошла ошибка при добавлении товара', 'error');
                }
            })
            .fail(function() {
                $button.removeClass('adding').prop('disabled', false);
                showNotification('Произошла ошибка при добавлении товара', 'error');
            });
    });
    
    // Добавление товара в избранное
    $(document).on('click', '.wishlist-btn, .btn-wishlist', function(e) {
        e.preventDefault();
        
        const $btn = $(this);
        const productId = $btn.data('product-id');
        
        Wishlist.isInWishlist(productId)
            .done(function(response) {
                if (response.in_wishlist) {
                    // Товар уже в избранном, удаляем
                    Wishlist.removeFromWishlist(response.wishlist_item_id)
                        .done(function(removeResponse) {
                            if (removeResponse.success) {
                                $btn.removeClass('active');
                                showNotification(removeResponse.message || 'Товар удален из избранного');
                            } else {
                                showNotification(removeResponse.message || 'Произошла ошибка при удалении товара', 'error');
                            }
                        });
                } else {
                    // Товар не в избранном, добавляем
                    Wishlist.addToWishlist(productId)
                        .done(function(addResponse) {
                            if (addResponse.success) {
                                $btn.addClass('active');
                                showNotification(addResponse.message || 'Товар добавлен в избранное');
                            } else {
                                showNotification(addResponse.message || 'Произошла ошибка при добавлении товара', 'error');
                            }
                        });
                }
            })
            .fail(function() {
                showNotification('Произошла ошибка при проверке избранного', 'error');
            });
    });
    
    // Отправка отзыва о товаре
    $(document).on('submit', '.review-form', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const productId = $form.data('product-id') || window.location.href.split('id=')[1];
        const rating = $form.find('input[name="rating"]:checked').val();
        const name = $form.find('#review-name').val();
        const email = $form.find('#review-email').val();
        const text = $form.find('#review-text').val();
        
        Reviews.addProductReview(productId, rating, name, email, text)
            .done(function(response) {
                if (response.success) {
                    showNotification(response.message || 'Ваш отзыв успешно добавлен');
                    $form[0].reset();
                    
                    // Перезагружаем страницу, чтобы отобразить новый отзыв
                    setTimeout(function() {
                        window.location.reload();
                    }, 1500);
                } else {
                    showNotification(response.message || 'Произошла ошибка при добавлении отзыва', 'error');
                }
            })
            .fail(function() {
                showNotification('Произошла ошибка при добавлении отзыва', 'error');
            });
    });
    
    // Функция для отображения уведомлений
    function showNotification(message, type = 'success') {
        // Проверяем, есть ли уже контейнер для уведомлений
        if ($('.notifications-container').length === 0) {
            $('body').append('<div class="notifications-container"></div>');
        }
        
        // Создаем уведомление
        const notification = $(`<div class="notification notification-${type}">${message}</div>`);
        $('.notifications-container').append(notification);
        
        // Удаляем уведомление через 3 секунды
        setTimeout(function() {
            notification.addClass('hide');
            setTimeout(function() {
                notification.remove();
            }, 300);
        }, 3000);
    }
}); 