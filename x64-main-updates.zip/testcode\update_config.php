<?php
// Обновляем конфигурационный файл
if (isset($_POST["webhook_url"])) {
    $webhook_url = $_POST["webhook_url"];
    $config_file = "includes/config/telegram_config.php";
    $config_content = file_get_contents($config_file);
    $config_content = preg_replace(
        '/define\(\'TELEGRAM_WEBHOOK_URL\',\s*\'.*\'\);/i',
        "define('TELEGRAM_WEBHOOK_URL', '" . $webhook_url . "');",
        $config_content
    );
    file_put_contents($config_file, $config_content);
    echo "<p>Конфигурационный файл успешно обновлен!</p>";
    echo "<p><a href=\"test_bot.php\">Перейти к тестированию бота</a></p>";
}
?>