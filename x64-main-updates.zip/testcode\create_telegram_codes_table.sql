-- Создаем таблицу для хранения кодов верификации Telegram
CREATE TABLE IF NOT EXISTS `telegram_verification_codes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `chat_id` VARCHAR(50) NOT NULL COMMENT 'ID чата в Telegram',
  `username` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Username пользователя в Telegram',
  `first_name` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Имя пользователя в Telegram',
  `last_name` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Фамилия пользователя в Telegram',
  `code` VARCHAR(10) NOT NULL COMMENT 'Код верификации',
  `expires_at` TIMESTAMP NOT NULL COMMENT 'Время истечения кода',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Время создания записи',
  UNIQUE KEY `uk_chat_id` (`chat_id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Коды верификации для привязки Telegram'; 