<?php
// Подключаем файлы конфигурации
require_once 'includes/config/db_config.php';

// Загружаем SQL скрипт
$sql = file_get_contents('update_categories.sql');

// Выполняем SQL запросы
if (mysqli_multi_query($conn, $sql)) {
    echo "Категории успешно обновлены на iPhone и Android.<br>";
    echo "<a href='admin/index.php?tab=products'>Вернуться в админ-панель</a>";
} else {
    echo "Ошибка при обновлении категорий: " . mysqli_error($conn);
}

// Закрываем соединение
mysqli_close($conn); 