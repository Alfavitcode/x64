<?php
// Заголовки для AJAX-запроса
header('Content-Type: application/json');

// Подключение к базе данных
require_once '../includes/config/db_functions.php';

// Начинаем сессию (для хранения корзины)
session_start();

// Проверяем, инициализирована ли корзина в сессии
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Получаем действие из запроса
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

// Ответ по умолчанию
$response = [
    'success' => false,
    'message' => 'Неизвестное действие',
    'cart_count' => count($_SESSION['cart'])
];

// Обрабатываем действие
switch ($action) {
    case 'add':
        // Добавление товара в корзину
        $productId = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        if ($productId > 0 && $quantity > 0) {
            // Проверяем, существует ли товар
            $product = getProductById($productId);
            
            if ($product) {
                // Товар существует, добавляем в корзину
                $itemIndex = -1;
                
                // Ищем, есть ли уже такой товар в корзине
                foreach ($_SESSION['cart'] as $index => $item) {
                    if ($item['product_id'] == $productId) {
                        $itemIndex = $index;
                        break;
                    }
                }
                
                if ($itemIndex >= 0) {
                    // Товар уже в корзине, увеличиваем количество
                    $_SESSION['cart'][$itemIndex]['quantity'] += $quantity;
                } else {
                    // Новый товар, добавляем в корзину
                    $_SESSION['cart'][] = [
                        'cart_item_id' => count($_SESSION['cart']) + 1,
                        'product_id' => $productId,
                        'quantity' => $quantity,
                        'added_at' => time()
                    ];
                }
                
                $response['success'] = true;
                $response['message'] = 'Товар успешно добавлен в корзину';
            } else {
                $response['message'] = 'Товар не найден';
            }
        } else {
            $response['message'] = 'Некорректные данные товара';
        }
        break;
        
    case 'remove':
        // Удаление товара из корзины
        $cartItemId = isset($_POST['cart_item_id']) ? (int)$_POST['cart_item_id'] : 0;
        
        if ($cartItemId > 0) {
            $itemIndex = -1;
            
            // Ищем товар в корзине
            foreach ($_SESSION['cart'] as $index => $item) {
                if ($item['cart_item_id'] == $cartItemId) {
                    $itemIndex = $index;
                    break;
                }
            }
            
            if ($itemIndex >= 0) {
                // Нашли товар, удаляем
                array_splice($_SESSION['cart'], $itemIndex, 1);
                
                $response['success'] = true;
                $response['message'] = 'Товар успешно удален из корзины';
            } else {
                $response['message'] = 'Товар не найден в корзине';
            }
        } else {
            $response['message'] = 'Некорректный ID товара в корзине';
        }
        break;
        
    case 'update':
        // Обновление количества товара в корзине
        $cartItemId = isset($_POST['cart_item_id']) ? (int)$_POST['cart_item_id'] : 0;
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;
        
        if ($cartItemId > 0 && $quantity > 0) {
            $itemIndex = -1;
            
            // Ищем товар в корзине
            foreach ($_SESSION['cart'] as $index => $item) {
                if ($item['cart_item_id'] == $cartItemId) {
                    $itemIndex = $index;
                    break;
                }
            }
            
            if ($itemIndex >= 0) {
                // Нашли товар, обновляем количество
                $_SESSION['cart'][$itemIndex]['quantity'] = $quantity;
                
                $response['success'] = true;
                $response['message'] = 'Количество товара успешно обновлено';
            } else {
                $response['message'] = 'Товар не найден в корзине';
            }
        } else {
            $response['message'] = 'Некорректные данные товара';
        }
        break;
        
    case 'get':
        // Получение содержимого корзины
        $cartItems = [];
        $totalPrice = 0;
        
        // Если в корзине есть товары
        if (!empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                $product = getProductById($item['product_id']);
                
                if ($product) {
                    // Рассчитываем стоимость позиции
                    $itemPrice = $product['price'] * $item['quantity'];
                    $totalPrice += $itemPrice;
                    
                    // Добавляем информацию о товаре
                    $cartItems[] = [
                        'cart_item_id' => $item['cart_item_id'],
                        'product_id' => $item['product_id'],
                        'quantity' => $item['quantity'],
                        'name' => $product['name'],
                        'price' => $product['price'],
                        'image' => $product['image'],
                        'item_price' => $itemPrice
                    ];
                }
            }
        }
        
        $response['success'] = true;
        $response['cart_items'] = $cartItems;
        $response['total_price'] = $totalPrice;
        $response['message'] = count($cartItems) > 0 ? 'Корзина получена' : 'Корзина пуста';
        break;
        
    case 'clear':
        // Очистка корзины
        $_SESSION['cart'] = [];
        
        $response['success'] = true;
        $response['message'] = 'Корзина успешно очищена';
        break;
        
    default:
        // Неизвестное действие
        $response['message'] = 'Неизвестное действие';
        break;
}

// Обновляем счетчик товаров в корзине
$response['cart_count'] = count($_SESSION['cart']);

// Возвращаем ответ в формате JSON
echo json_encode($response);
?> 