<?php
// Подключаем файл конфигурации
require_once 'includes/config/db_config.php';

// Загружаем SQL-скрипт
$sql = file_get_contents('telegram_integration.sql');

// Выполняем SQL-запросы
if (mysqli_multi_query($conn, $sql)) {
    echo "Поля для интеграции с Telegram успешно добавлены в базу данных.<br>";
    echo "<a href='index.php'>Вернуться на главную</a>";
} else {
    echo "Ошибка при обновлении базы данных: " . mysqli_error($conn);
}

// Закрываем соединение
mysqli_close($conn);
?> 