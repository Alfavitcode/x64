-- Очищаем таблицу категорий
TRUNCATE TABLE categories;

-- Добавляем новые категории iPhone и Android
INSERT INTO categories (id, name, description, image, parent_id, created_at) VALUES
(1, 'iPhone', 'Смартфоны iPhone от Apple', '/img/categories/iphone.jpg', NULL, NOW()),
(2, 'Android', 'Смартфоны на операционной системе Android', '/img/categories/android.jpg', NULL, NOW());

-- Сбрасываем автоинкремент
ALTER TABLE categories AUTO_INCREMENT = 3; 