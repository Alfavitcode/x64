-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 20 2025 г., 12:06
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `x64new`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`) VALUES
(36, 13, 2, 1, '2025-03-31 07:40:53'),
(37, 13, 3, 1, '2025-03-31 07:40:59');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `image`, `parent_id`, `created_at`) VALUES
(1, 'Электроника', 'Электронные устройства и гаджеты', '/img/categories/electronics.jpg', NULL, '2025-05-20 08:13:13'),
(2, 'Ноутбуки', 'Ноутбуки и аксессуары', '/img/categories/laptops.jpg', 1, '2025-05-20 08:13:13'),
(3, 'Планшеты', 'Планшеты и электронные книги', '/img/categories/tablets.jpg', 1, '2025-05-20 08:13:13'),
(4, 'Смартфоны', 'Мобильные телефоны и смартфоны', '/img/categories/smartphones.jpg', 1, '2025-05-20 08:13:13'),
(5, 'Игры и развлечения', 'Игровые консоли и аксессуары', '/img/categories/games.jpg', NULL, '2025-05-20 08:13:13');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','completed','cancelled','closed') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `is_closed` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_price`, `status`, `created_at`, `address`, `city`, `region`, `postal_code`, `phone`, `is_closed`) VALUES
(4, 15, '67000.00', 'completed', '2025-03-19 17:05:00', 'Тургенева 97б', 'Чернь', 'Тульская область', '303301', '+79053024129', 0),
(5, 15, '48999.00', 'pending', '2025-03-19 17:06:02', 'Тургенева 97б', 'Чернь', 'Тульская область', '303301', '+79053024129', 0),
(6, 15, '134000.00', 'cancelled', '2025-03-19 17:06:34', 'Тургенева 97б', 'Чернь', 'Тульская область', '303031', '+79053024129', 0),
(7, 15, '146997.00', 'completed', '2025-03-19 17:07:00', 'Тургенева 97б', 'Чернь', 'Тульская область', '303301', '+79053024129', 0),
(8, 16, '67000.00', 'pending', '2025-03-24 20:07:02', 'г. Мценск, Улица Машиностроителей, 2', 'Мценск', 'Далеко', '303031', '+79622763927', 0),
(9, 18, '182999.00', 'completed', '2025-03-24 20:11:20', 'Улиуа Пушкина, дом Колотушкина', 'Йошкар-Ола', 'РФ', '111111', '+79583333333', 0),
(10, 13, '48999.00', 'pending', '2025-03-24 20:13:43', 'Тургенева 97б', 'Чернь', 'Тульская область', '231212', '+79192000731', 0),
(11, 20, '48999.00', 'processing', '2025-03-25 07:33:52', 'Улица Садовая 40', 'Г. Мценсе', 'Орловская область', '303030', '79004861595', 0),
(12, 13, '146997.00', 'completed', '2025-03-25 08:48:18', 'г. Мценск, Улица Машиностроителей, 2', 'Мценск', 'Далеко', '303031', '+79192000731', 0),
(13, 13, '227999.00', 'completed', '2025-03-27 07:11:09', 'г. Мценск, Улица Машиностроителей, 2', 'Мценск', 'Далеко', '303031', '+79192000731', 1),
(14, 13, '30000.00', 'cancelled', '2025-03-27 14:03:47', 'Тургенева 97б', 'Мценск', 'Тульская область', '303031', '+79192000731', 1),
(15, 21, '32000.00', 'completed', '2025-03-27 17:01:31', 'Пушкина', 'Ростов-на-дону', 'Ростовская облость', '344057', '+79064209157', 1),
(17, 22, '160999.00', 'completed', '2025-03-27 20:21:02', 'Мценск ул Машиностроителей', 'Мцегс', 'Орл обл', '303003', '+79961692950', 1),
(18, 13, '67000.00', 'completed', '2025-03-28 07:18:16', 'пиап', 'апапа', '454е', '34334', '+79192000731', 1),
(19, 13, '99000.00', 'completed', '2025-03-30 18:03:49', '11', '12', '13', '3039', '+79192000731', 1),
(20, 13, '67000.00', 'completed', '2025-03-31 07:36:20', 'АДВА', '123', '1343', '303101', '+79192000731', 1),
(21, 16, '67000.00', 'pending', '2025-04-03 20:07:13', 'г. Мценск, Улица Машиностроителей, 2', 'Мценск', 'Далеко', '303031', '+79622763927', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(4, 4, 2, 1, '67000.00'),
(5, 5, 3, 1, '48999.00'),
(6, 6, 2, 2, '67000.00'),
(7, 7, 3, 3, '48999.00'),
(8, 8, 2, 1, '67000.00'),
(9, 9, 2, 2, '67000.00'),
(10, 9, 3, 1, '48999.00'),
(11, 10, 3, 1, '48999.00'),
(12, 11, 3, 1, '48999.00'),
(13, 12, 3, 3, '48999.00'),
(14, 13, 2, 1, '67000.00'),
(15, 13, 3, 1, '48999.00'),
(16, 13, 6, 1, '30000.00'),
(17, 13, 7, 1, '30000.00'),
(18, 13, 8, 1, '32000.00'),
(19, 13, 9, 1, '20000.00'),
(20, 14, 7, 1, '30000.00'),
(21, 15, 8, 1, '32000.00'),
(23, 17, 9, 1, '20000.00'),
(24, 17, 8, 1, '32000.00'),
(25, 17, 7, 1, '30000.00'),
(26, 17, 6, 1, '30000.00'),
(27, 17, 3, 1, '48999.00'),
(28, 18, 2, 1, '67000.00'),
(29, 19, 8, 1, '32000.00'),
(30, 19, 2, 1, '67000.00'),
(31, 20, 2, 1, '67000.00'),
(32, 21, 2, 1, '67000.00');

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `category` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  `is_bestseller` tinyint(1) NOT NULL DEFAULT '0',
  `discount` int NOT NULL DEFAULT '0',
  `rating` decimal(3,1) NOT NULL DEFAULT '0.0',
  `reviews_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `name`, `description`, `price`, `category`, `image`, `sku`, `stock`, `is_new`, `is_bestseller`, `discount`, `rating`, `reviews_count`, `created_at`, `updated_at`) VALUES
(1, 'Смартфон XYZ Pro', 'Современный смартфон с высокой производительностью и качественной камерой.', '29990.00', 'Электроника', '/img/products/8 красный.PNG', 'SP-001', 15, 1, 1, 0, '4.5', 24, '2025-05-20 08:13:13', '2025-05-20 08:13:13'),
(2, 'Умные часы SmartLife', 'Следите за своим здоровьем и оставайтесь на связи с умными часами SmartLife.', '7990.00', 'Электроника', '/img/products/8 белый.PNG', 'SW-002', 25, 0, 0, 20, '4.0', 15, '2025-05-20 08:13:13', '2025-05-20 08:13:13'),
(3, 'Беспроводные наушники SoundPro', 'Наслаждайтесь качественным звуком без проводов.', '5490.00', 'Электроника', '/img/products/8 розовое золото.PNG', 'HP-003', 30, 0, 1, 0, '5.0', 42, '2025-05-20 08:13:13', '2025-05-20 08:13:13'),
(4, 'Фотокамера ProShot', 'Профессиональная фотокамера для создания идеальных кадров.', '42490.00', 'Электроника', '/img/products/14 red.jpg', 'CM-004', 8, 1, 0, 15, '3.5', 7, '2025-05-20 08:13:13', '2025-05-20 08:13:13'),
(5, 'Ноутбук UltraBook', 'Тонкий и легкий ноутбук для работы и развлечений.', '59990.00', 'Ноутбуки', '/img/products/placeholder-1.jpg', 'LT-005', 12, 1, 1, 0, '4.7', 31, '2025-05-20 08:13:13', '2025-05-20 08:13:13'),
(6, 'Планшет TabPro', 'Мощный планшет с ярким дисплеем для работы и развлечений.', '24990.00', 'Планшеты', '/img/products/placeholder-2.jpg', 'TB-006', 20, 0, 1, 10, '4.2', 18, '2025-05-20 08:13:13', '2025-05-20 08:13:13'),
(7, 'Умная колонка HomePod', 'Умная колонка с качественным звуком и голосовым помощником.', '8990.00', 'Электроника', '/img/products/placeholder-3.jpg', 'SP-007', 22, 1, 0, 0, '4.0', 9, '2025-05-20 08:13:13', '2025-05-20 08:13:13'),
(8, 'Игровая консоль GameMaster', 'Мощная игровая консоль для настоящих геймеров.', '39990.00', 'Игры и развлечения', '/img/products/placeholder-4.jpg', 'GM-008', 5, 0, 1, 0, '4.9', 37, '2025-05-20 08:13:13', '2025-05-20 08:13:13');

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `product_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `rating` int NOT NULL,
  `text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `name`, `email`, `rating`, `text`, `created_at`) VALUES
(1, 1, 'Александр', 'alex@example.com', 5, 'Отличный смартфон! Камера супер, батарея держит долго.', '2023-06-15 07:23:45'),
(2, 1, 'Мария', 'maria@example.com', 4, 'Хороший телефон за свои деньги, но есть небольшие недочеты в работе интерфейса.', '2023-06-22 11:17:32'),
(3, 2, 'Дмитрий', 'dmitry@example.com', 4, 'Удобные часы, но хотелось бы больше функций для спорта.', '2023-07-05 06:45:18'),
(4, 3, 'Елена', 'elena@example.com', 5, 'Звук просто потрясающий! Очень доволен покупкой!', '2023-07-12 13:33:27'),
(5, 3, 'Иван', 'ivan@example.com', 5, 'Наушники супер! Долго держат заряд и отлично сидят в ушах.', '2023-07-18 08:22:49');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(150) NOT NULL,
  `patronymic` varchar(150) NOT NULL,
  `phone` char(17) NOT NULL,
  `login` varchar(150) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `patronymic`, `phone`, `login`, `email`, `password`, `role`) VALUES
(13, 'Михаил', 'Калашников', 'Дмитриевич', '+79192000731', 'Rebiks', 'Rebiks@mail.ru', '$2y$10$7lK4mGiO5yIaRmmMdGdZlusD1/hMhhsLJEQHA.6Qo/yXrwKxhIBpe', 'Администратор'),
(14, 'Павел', 'Кравцев', 'Викторович', '+79053024125', 'Kravetc', 'Kravetc@mail.ru', '$2y$10$b1wj70dSaP66YnV6bm6buuSEDTOx0a4091qAap3tu17UiKnTsMCau', 'Пользователь'),
(15, 'Денис', 'Филимонов', 'Юрьевич', '+79053024129', 'alfavittt', 'alfavittt@mail.ru', '$2y$10$P81XQ9SihQnamblm.nPJSeNrArKjFJFDQGfHgrkVusqyBltuqQUOO', 'Пользователь'),
(16, 'Денис', 'Филимонов', 'Юрьевич', '+79622763927', 'Alfavit', 'Alfavitden@gmail.com', '$2y$10$hCSOujDO.I7OX2GvXS2gy.Q6Zys9sEQ7Vu.fQoSu7I5jJ7INWpzm.', 'Администратор'),
(17, 'Михаил', 'Калашников', 'Дмитринвичч', '+79192000730', 'Misha', 'mail@mail.ru', '$2y$10$NDzFC8.a9W9SWRhDYvum7O3SPlt7aKed3uda66SeQkw2ahGohUE2q', 'Пользователь'),
(18, 'Пипка', 'Пипкова', 'Пипковна', '+79583333333', 'qwerty', 'pochta@mail.ru', '$2y$10$VVSpk.qfWtZgQ.iNK3BokOMjuRXxf/egs7G5FlKv8En5wZQfHcWYy', 'Пользователь'),
(19, 'Я', 'Не', 'Миша', '+79622763925', 'Misha1', 'asd@mail.ru', '$2y$10$k2Cxr381S7iUCS6pbQYNeOFI9tOndxm6BZLzK0D1ZnmPck0oa8tkO', 'Пользователь'),
(20, 'В', 'В', 'В', '79004861595', 'Ter', 'na_gore_stoit_koroli@mail.ru', '$2y$10$/NHBZAx./sJrDNycPfMsgu82fyk1MdZTIe4qF8D63sEeQaFTStJke', 'Пользователь'),
(21, 'Михаил', 'Садиков', 'Михайлович', '+79064209157', 'MihanTT', 'MihanTT@mail.ru', '$2y$10$1T6gVshnBDB4kiXpIaGWB.6YGGEOUcU8sgkhny/8ImXbUlvrnXF8C', 'Пользователь'),
(22, 'Владислав', 'Суетной', 'Суетологович', '+79961692950', 'Vlad_suetolog', 'vladsuetadela@mail.ru', '$2y$10$/hAN0VSBkAmx9ZwSL4D12uGsQq6U6WAPRCI/rrmy9cda5tnAIeBGS', 'Пользователь'),
(23, 'Кирилл', 'Сухочев', 'Сергеевич', '89685748539', 'MGE_BRAT', 'PARAVOZIK@MAIL.ru', '$2y$10$.ZdmzRWFy.iOlNQKdhUh7.1L1mGtLQVqiJVI7/V8FzYe2acUF9phu', 'Пользователь');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_idx` (`category`),
  ADD KEY `is_new_idx` (`is_new`),
  ADD KEY `is_bestseller_idx` (`is_bestseller`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id_idx` (`product_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
