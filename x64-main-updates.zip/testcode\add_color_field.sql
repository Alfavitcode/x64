-- Добавляем поле color в таблицу product
ALTER TABLE product ADD COLUMN color VARCHAR(50) DEFAULT NULL AFTER category;

-- Обновляем существующие записи, устанавливая значение по умолчанию
UPDATE product SET color = 'black' WHERE color IS NULL; 