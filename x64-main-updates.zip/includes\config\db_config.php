<?php
// Параметры подключения к базе данных для OpenServer
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'x64new');

// Устанавливаем соединение с базой данных MySQL
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Проверяем соединение
if($conn === false){
    die("ОШИБКА: Невозможно подключиться к базе данных. " . mysqli_connect_error());
}

// Устанавливаем кодировку
mysqli_set_charset($conn, "utf8");
?> 