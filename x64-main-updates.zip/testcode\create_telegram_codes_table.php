<?php
// Подключаем файл конфигурации
require_once 'includes/config/db_config.php';

// Загружаем SQL-скрипт
$sql = file_get_contents('create_telegram_codes_table.sql');

// Выполняем SQL-запросы
if (mysqli_query($conn, $sql)) {
    echo "Таблица telegram_verification_codes успешно создана.<br>";
    echo "<a href='index.php'>Вернуться на главную</a>";
} else {
    echo "Ошибка при создании таблицы: " . mysqli_error($conn);
}

// Закрываем соединение
mysqli_close($conn);
?> 