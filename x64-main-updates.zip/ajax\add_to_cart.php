<?php
// Начинаем сессию
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Подключаем необходимые файлы
require_once '../includes/config/db_config.php';
require_once '../includes/config/db_functions.php';

// Проверяем, что запрос выполнен методом POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из запроса
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    
    // Валидация данных
    if ($product_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Некорректный ID товара'
        ]);
        exit;
    }
    
    if ($quantity <= 0 || $quantity > 99) {
        echo json_encode([
            'success' => false,
            'message' => 'Некорректное количество товара'
        ]);
        exit;
    }
    
    // Проверяем, есть ли товар в наличии
    $product = getProductById($product_id);
    if (!$product) {
        echo json_encode([
            'success' => false,
            'message' => 'Товар не найден'
        ]);
        exit;
    }
    
    if ($product['stock'] <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Товар отсутствует в наличии'
        ]);
        exit;
    }
    
    // Определяем ID сессии и пользователя
    $session_id = session_id();
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    
    // Добавляем товар в корзину
    $result = addToCart($product_id, $session_id, $quantity, $user_id);
    
    // Если товар успешно добавлен, получаем обновленное количество товаров в корзине
    if ($result['success']) {
        $result['cart_count'] = getCartItemCount($session_id, $user_id);
    }
    
    // Возвращаем результат в формате JSON
    echo json_encode($result);
} else {
    // Если запрос выполнен не методом POST, возвращаем ошибку
    echo json_encode([
        'success' => false,
        'message' => 'Недопустимый метод запроса'
    ]);
}
?> 