<?php
// Этот скрипт имитирует запрос от Telegram к вашему вебхуку

// Подключаем файл конфигурации
require_once 'includes/config/telegram_config.php';
require_once 'includes/config/db_config.php';
require_once 'includes/config/db_functions.php';

// Получаем команду из параметра запроса
$command = isset($_GET['command']) ? $_GET['command'] : '/start';
$chat_id = isset($_GET['chat_id']) ? $_GET['chat_id'] : '123456789';
$username = isset($_GET['username']) ? $_GET['username'] : 'test_user';
$first_name = isset($_GET['first_name']) ? $_GET['first_name'] : 'Тестовый';
$last_name = isset($_GET['last_name']) ? $_GET['last_name'] : 'Пользователь';

// Формируем данные запроса в формате Telegram
$update = [
    'update_id' => mt_rand(100000, 999999),
    'message' => [
        'message_id' => mt_rand(1000, 9999),
        'from' => [
            'id' => $chat_id,
            'is_bot' => false,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'username' => $username,
            'language_code' => 'ru'
        ],
        'chat' => [
            'id' => $chat_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'username' => $username,
            'type' => 'private'
        ],
        'date' => time(),
        'text' => $command
    ]
];

// Преобразуем в JSON
$json_data = json_encode($update);

// Создаем временный файл для логирования
$log_file = __DIR__ . '/api/telegram_log.txt';
file_put_contents($log_file, date('Y-m-d H:i:s') . " - Тестовый запрос\n", FILE_APPEND);
file_put_contents($log_file, date('Y-m-d H:i:s') . " - Входящие данные: " . $json_data . "\n", FILE_APPEND);
file_put_contents($log_file, date('Y-m-d H:i:s') . " - Декодированные данные: " . print_r($update, true) . "\n\n", FILE_APPEND);

// Обработка команды напрямую, без включения файла telegram_webhook.php
if (isset($update['message'])) {
    $message = $update['message'];
    $chat_id = $message['chat']['id'];
    $text = isset($message['text']) ? $message['text'] : '';
    $username = isset($message['from']['username']) ? $message['from']['username'] : '';
    $first_name = isset($message['from']['first_name']) ? $message['from']['first_name'] : '';
    $last_name = isset($message['from']['last_name']) ? $message['from']['last_name'] : '';
    
    // Создаем директорию для хранения сессий, если она не существует
    $sessions_dir = __DIR__ . '/api/telegram_sessions';
    if (!file_exists($sessions_dir)) {
        mkdir($sessions_dir, 0755, true);
    }
    
    // Обработка команды /start
    if ($text === '/start') {
        // Сохраняем информацию о пользователе в сессионный файл
        $user_data = [
            'chat_id' => $chat_id,
            'username' => $username,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'timestamp' => time()
        ];
        
        // Сохраняем данные пользователя в файл
        file_put_contents($sessions_dir . '/' . $chat_id . '.json', json_encode($user_data));
        
        $response = "Добро пожаловать, " . htmlspecialchars($first_name) . "! 👋\n\n";
        $response .= "Этот бот позволяет привязать ваш аккаунт Telegram к аккаунту на сайте x64.\n\n";
        $response .= "Для получения кода привязки, отправьте команду /code\n\n";
        $response .= "Если у вас возникли вопросы, напишите /help";
        
        $result = sendTelegramMessage($chat_id, $response);
    }
    
    // Обработка команды /code
    else if ($text === '/code') {
        // Проверяем, есть ли сохраненная информация о пользователе
        $session_file = $sessions_dir . '/' . $chat_id . '.json';
        
        if (file_exists($session_file)) {
            $user_data = json_decode(file_get_contents($session_file), true);
            
            // Проверяем, привязан ли уже этот Telegram ID к какому-либо аккаунту
            $user = getUserByTelegramId($chat_id);
            
            if ($user) {
                $response = "Ваш Telegram уже привязан к аккаунту " . $user['fullname'] . ".\n\n";
                $response .= "Если вы хотите отвязать аккаунт, используйте соответствующую функцию в личном кабинете на сайте.";
                $result = sendTelegramMessage($chat_id, $response);
            } else {
                // Генерируем временный код для привязки
                $code = sprintf("%05d", mt_rand(0, 99999));
                $expires = date('Y-m-d H:i:s', strtotime('+30 minutes'));
                
                // Проверяем, существует ли таблица telegram_verification_codes
                $check_table_sql = "SHOW TABLES LIKE 'telegram_verification_codes'";
                $check_result = mysqli_query($conn, $check_table_sql);
                
                if (mysqli_num_rows($check_result) == 0) {
                    // Создаем таблицу, если она не существует
                    $create_table_sql = "CREATE TABLE telegram_verification_codes (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        chat_id VARCHAR(50) NOT NULL,
                        username VARCHAR(100) NULL,
                        first_name VARCHAR(100) NULL,
                        last_name VARCHAR(100) NULL,
                        code VARCHAR(10) NOT NULL,
                        expires_at TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE KEY (chat_id)
                    )";
                    mysqli_query($conn, $create_table_sql);
                }
                
                // Сохраняем код в базе данных для последующей проверки
                $sql = "INSERT INTO telegram_verification_codes (chat_id, username, first_name, last_name, code, expires_at) 
                        VALUES ('$chat_id', " . 
                        ($username ? "'$username'" : "NULL") . ", " .
                        ($first_name ? "'" . mysqli_real_escape_string($conn, $first_name) . "'" : "NULL") . ", " .
                        ($last_name ? "'" . mysqli_real_escape_string($conn, $last_name) . "'" : "NULL") . ", " .
                        "'$code', '$expires')
                        ON DUPLICATE KEY UPDATE 
                        code = '$code', 
                        expires_at = '$expires',
                        username = " . ($username ? "'$username'" : "username") . ",
                        first_name = " . ($first_name ? "'" . mysqli_real_escape_string($conn, $first_name) . "'" : "first_name") . ",
                        last_name = " . ($last_name ? "'" . mysqli_real_escape_string($conn, $last_name) . "'" : "last_name");
                
                if (mysqli_query($conn, $sql)) {
                    $response = "Ваш код для привязки аккаунта: <b>$code</b>\n\n";
                    $response .= "Введите этот код на странице привязки Telegram в личном кабинете на сайте.\n\n";
                    $response .= "Код действителен в течение 30 минут.";
                    $result = sendTelegramMessage($chat_id, $response);
                } else {
                    $response = "Произошла ошибка при генерации кода. Пожалуйста, попробуйте позже.";
                    $result = sendTelegramMessage($chat_id, $response);
                }
            }
        } else {
            $response = "Для начала работы с ботом, отправьте команду /start";
            $result = sendTelegramMessage($chat_id, $response);
        }
    }
    
    // Обработка команды /help
    else if ($text === '/help') {
        $response = "Справка по командам бота:\n\n";
        $response .= "/start - Начать работу с ботом\n";
        $response .= "/code - Получить код для привязки аккаунта\n";
        $response .= "/help - Показать эту справку\n";
        $response .= "/status - Проверить статус привязки аккаунта\n\n";
        $response .= "Для привязки аккаунта получите код с помощью команды /code и введите его на странице привязки Telegram в личном кабинете на сайте.";
        
        $result = sendTelegramMessage($chat_id, $response);
    }
    
    // Обработка команды /status
    else if ($text === '/status') {
        // Проверяем, привязан ли аккаунт
        $user = getUserByTelegramId($chat_id);
        
        if ($user) {
            $response = "Ваш Telegram привязан к аккаунту:\n\n";
            $response .= "Имя: " . $user['fullname'] . "\n";
            $response .= "Email: " . $user['email'] . "\n";
            $response .= "Телефон: " . $user['phone'] . "\n\n";
            $response .= "Для отвязки аккаунта используйте соответствующую функцию в личном кабинете на сайте.";
        } else {
            $response = "Ваш Telegram не привязан к аккаунту на сайте.\n\n";
            $response .= "Для привязки аккаунта выполните следующие шаги:\n";
            $response .= "1. Получите код с помощью команды /code\n";
            $response .= "2. Войдите в свой аккаунт на сайте\n";
            $response .= "3. Перейдите в раздел \"Привязка Telegram\"\n";
            $response .= "4. Введите полученный код в соответствующее поле";
        }
        
        $result = sendTelegramMessage($chat_id, $response);
    }
    
    // Если сообщение не распознано
    else {
        $response = "Я не понимаю эту команду. Пожалуйста, используйте /help для получения списка доступных команд.";
        $result = sendTelegramMessage($chat_id, $response);
    }
}

// Выводим форму для тестирования
echo '<h1>Тестирование команд Telegram бота</h1>';
echo '<form method="get">';
echo '<label for="command">Команда:</label>';
echo '<select name="command" id="command">';
echo '<option value="/start"' . ($command === '/start' ? ' selected' : '') . '>/start</option>';
echo '<option value="/code"' . ($command === '/code' ? ' selected' : '') . '>/code</option>';
echo '<option value="/help"' . ($command === '/help' ? ' selected' : '') . '>/help</option>';
echo '<option value="/status"' . ($command === '/status' ? ' selected' : '') . '>/status</option>';
echo '</select><br><br>';

echo '<label for="chat_id">ID чата:</label>';
echo '<input type="text" name="chat_id" id="chat_id" value="' . htmlspecialchars($chat_id) . '"><br><br>';

echo '<label for="username">Имя пользователя:</label>';
echo '<input type="text" name="username" id="username" value="' . htmlspecialchars($username) . '"><br><br>';

echo '<label for="first_name">Имя:</label>';
echo '<input type="text" name="first_name" id="first_name" value="' . htmlspecialchars($first_name) . '"><br><br>';

echo '<label for="last_name">Фамилия:</label>';
echo '<input type="text" name="last_name" id="last_name" value="' . htmlspecialchars($last_name) . '"><br><br>';

echo '<input type="submit" value="Отправить команду">';
echo '</form>';

echo '<h2>Отправленные данные:</h2>';
echo '<pre>' . htmlspecialchars($json_data) . '</pre>';

echo '<h2>Результат выполнения команды:</h2>';
if (isset($response)) {
    echo '<div style="border: 1px solid #ccc; padding: 10px; margin-bottom: 20px;">';
    echo nl2br(htmlspecialchars($response));
    echo '</div>';
    
    echo '<h3>Статус отправки сообщения:</h3>';
    echo '<pre>' . (isset($result) ? htmlspecialchars(print_r($result, true)) : 'Сообщение не отправлено') . '</pre>';
}

// Проверяем, создан ли лог-файл
if (file_exists($log_file)) {
    echo '<h2>Содержимое лог-файла:</h2>';
    echo '<pre>' . htmlspecialchars(file_get_contents($log_file)) . '</pre>';
}

/**
 * Отправляет сообщение в Telegram
 * 
 * @param int $chat_id ID чата
 * @param string $text Текст сообщения
 * @return mixed Результат отправки
 */
function sendTelegramMessage($chat_id, $text) {
    // Используем токен из конфигурации
    $bot_token = TELEGRAM_BOT_TOKEN;
    
    // Формируем данные для отправки
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    
    // Отправляем запрос к API Telegram
    $ch = curl_init("https://api.telegram.org/bot$bot_token/sendMessage");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}
?> 