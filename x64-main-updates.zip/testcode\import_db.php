<?php
// Параметры подключения к серверу MySQL
$server = 'localhost';
$username = 'root';
$password = '';
$database = 'x64new';
$sql_file = 'x64new.sql';

// Проверяем наличие файла SQL
if (!file_exists($sql_file)) {
    die("Ошибка: Файл базы данных не найден ($sql_file)");
}

// Устанавливаем соединение с MySQL сервером
$conn = mysqli_connect($server, $username, $password);

if (!$conn) {
    die("Ошибка подключения к MySQL: " . mysqli_connect_error());
}

// Проверяем, существует ли база данных, если нет - создаем
$check_db = mysqli_query($conn, "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$database'");

if (mysqli_num_rows($check_db) == 0) {
    $create_db = mysqli_query($conn, "CREATE DATABASE `$database` CHARACTER SET utf8 COLLATE utf8_general_ci");
    
    if (!$create_db) {
        die("Ошибка при создании базы данных: " . mysqli_error($conn));
    }
    
    echo "База данных '$database' успешно создана.<br>";
} else {
    echo "База данных '$database' уже существует.<br>";
}

// Выбираем созданную базу данных
mysqli_select_db($conn, $database);

// Считываем SQL-файл
$sql_content = file_get_contents($sql_file);

// Разделяем SQL-файл на отдельные запросы
$queries = explode(';', $sql_content);

// Выполняем каждый запрос
foreach ($queries as $query) {
    $query = trim($query);
    
    if (empty($query)) {
        continue;
    }
    
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        echo "Ошибка выполнения запроса: " . mysqli_error($conn) . "<br>";
        echo "Запрос: " . $query . "<br><br>";
    }
}

echo "Импорт базы данных успешно завершен!<br>";
echo "<a href='index.php'>Вернуться на главную</a>";

// Закрываем соединение
mysqli_close($conn);
?> 