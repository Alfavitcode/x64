<?php
// Включаем вывод ошибок для отладки
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// HTML заголовок и подключение Bootstrap
echo '<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Настройка базы данных</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h2>Настройка базы данных</h2>
            </div>
            <div class="card-body">';

// Подключаем файл конфигурации базы данных
require_once 'includes/config/db_config.php';

// Получаем глобальное соединение с базой данных
global $conn;

// Загружаем SQL файл
$sql_file = file_get_contents('users_table.sql');

// Проверяем, успешно ли прочитан файл
if ($sql_file === false) {
    die('<div class="alert alert-danger">Ошибка при чтении SQL файла</div>');
}

// Разбиваем SQL файл на отдельные запросы
$queries = explode(';', $sql_file);

// Счетчики
$total_queries = 0;
$successful_queries = 0;

echo '<h4>Выполнение SQL-запросов:</h4>';
echo '<div class="alert alert-info">';

// Выполняем каждый запрос
foreach ($queries as $query) {
    $query = trim($query);
    
    // Пропускаем пустые запросы и комментарии
    if (empty($query) || strpos($query, '--') === 0) {
        continue;
    }
    
    $total_queries++;
    
    // Выполняем запрос
    if (mysqli_query($conn, $query)) {
        $successful_queries++;
        echo '<div class="text-success">✓ Запрос успешно выполнен: ' . htmlspecialchars(substr($query, 0, 100)) . '...</div>';
    } else {
        echo '<div class="text-danger">✗ Ошибка при выполнении запроса: ' . htmlspecialchars(substr($query, 0, 100)) . '...</div>';
        echo '<div class="text-danger">Сообщение об ошибке: ' . mysqli_error($conn) . '</div><br>';
    }
}

echo '</div>';

// Выводим итоговую информацию
echo '<div class="alert alert-' . ($successful_queries === $total_queries ? 'success' : 'warning') . '">';
echo "<strong>Всего запросов:</strong> $total_queries<br>";
echo "<strong>Успешно выполнено:</strong> $successful_queries";
echo '</div>';

// Создаем тестового администратора, если его еще нет
$admin_login = 'admin';
$check_admin = mysqli_query($conn, "SELECT id FROM users WHERE login = '$admin_login'");

if (mysqli_num_rows($check_admin) === 0) {
    $admin_password_hash = password_hash('admin123', PASSWORD_DEFAULT);
    $insert_admin = "INSERT INTO users (fullname, email, phone, login, password, role) VALUES 
                    ('Администратор Сайта', 'admin@example.com', '+7 (999) 999-99-99', 
                    'admin', '$admin_password_hash', 'admin')";
    
    if (mysqli_query($conn, $insert_admin)) {
        echo '<div class="alert alert-success">Создан тестовый администратор (логин: <strong>admin</strong>, пароль: <strong>admin123</strong>)</div>';
    } else {
        echo '<div class="alert alert-danger">Ошибка при создании тестового администратора: ' . mysqli_error($conn) . '</div>';
    }
}

echo '<div class="mt-4">
    <a href="account/register.php" class="btn btn-primary me-2">Перейти на страницу регистрации</a>
    <a href="account/login.php" class="btn btn-success">Перейти на страницу входа</a>
</div>';

echo '</div>
        <div class="card-footer text-muted">
            <small>База данных успешно настроена. Теперь вы можете использовать систему регистрации и авторизации.</small>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>';
?> 