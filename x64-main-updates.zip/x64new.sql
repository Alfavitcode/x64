-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 21 2025 г., 18:13
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `x64new`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`) VALUES
(36, 13, 2, 1, '2025-03-31 07:40:53'),
(37, 13, 3, 1, '2025-03-31 07:40:59');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `image`, `parent_id`, `created_at`) VALUES
(1, 'iPhone', 'Смартфоны iPhone от Apple', '/img/categories/iphone.jpg', NULL, '2025-05-20 20:32:35'),
(2, 'Android', 'Смартфоны на операционной системе Android', '/img/categories/android.jpg', NULL, '2025-05-20 20:32:35');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','completed','cancelled','closed') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `is_closed` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(4, 4, 2, 1, '67000.00'),
(5, 5, 3, 1, '48999.00'),
(6, 6, 2, 2, '67000.00'),
(7, 7, 3, 3, '48999.00'),
(8, 8, 2, 1, '67000.00'),
(9, 9, 2, 2, '67000.00'),
(10, 9, 3, 1, '48999.00'),
(11, 10, 3, 1, '48999.00'),
(12, 11, 3, 1, '48999.00'),
(13, 12, 3, 3, '48999.00'),
(14, 13, 2, 1, '67000.00'),
(15, 13, 3, 1, '48999.00'),
(16, 13, 6, 1, '30000.00'),
(17, 13, 7, 1, '30000.00'),
(18, 13, 8, 1, '32000.00'),
(19, 13, 9, 1, '20000.00'),
(20, 14, 7, 1, '30000.00'),
(21, 15, 8, 1, '32000.00'),
(23, 17, 9, 1, '20000.00'),
(24, 17, 8, 1, '32000.00'),
(25, 17, 7, 1, '30000.00'),
(26, 17, 6, 1, '30000.00'),
(27, 17, 3, 1, '48999.00'),
(28, 18, 2, 1, '67000.00'),
(29, 19, 8, 1, '32000.00'),
(30, 19, 2, 1, '67000.00'),
(31, 20, 2, 1, '67000.00'),
(32, 21, 2, 1, '67000.00');

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `category` varchar(100) NOT NULL,
  `color` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  `is_bestseller` tinyint(1) NOT NULL DEFAULT '0',
  `discount` int NOT NULL DEFAULT '0',
  `rating` decimal(3,1) NOT NULL DEFAULT '0.0',
  `reviews_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `name`, `description`, `price`, `category`, `color`, `image`, `sku`, `stock`, `is_new`, `is_bestseller`, `discount`, `rating`, `reviews_count`, `created_at`, `updated_at`) VALUES
(9, 'Крышка iPhone 14', 'Крышка iPhone 14 RED', '900.00', 'iPhone', 'red', '/img/products/14 red.jpg', '1', 50, 1, 0, 5, '0.0', 0, '2025-05-20 20:33:59', '2025-05-20 20:37:19'),
(10, 'Крышка iPhone 8 ', 'Задняя крышка для телефона iPhone 8 Розовое золото', '700.00', 'iPhone', NULL, '/img/products/8 розовое золото.PNG', '2', 10, 1, 0, 0, '0.0', 0, '2025-05-21 08:36:49', '2025-05-21 08:36:49'),
(11, 'Крышка iPhone 14', 'Задняя крышка iPhone 14 синяя', '800.00', 'iPhone', NULL, '/img/products/8 красный.PNG', '3', 50, 1, 0, 10, '0.0', 0, '2025-05-21 09:06:46', '2025-05-21 09:06:46');

-- --------------------------------------------------------

--
-- Структура таблицы `product_colors`
--

CREATE TABLE `product_colors` (
  `id` int NOT NULL,
  `product_id` int NOT NULL,
  `sku` varchar(50) NOT NULL COMMENT 'Артикул для группировки вариантов одного товара',
  `color_name` varchar(50) NOT NULL,
  `color_code` varchar(20) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `description` text COMMENT 'Описание для конкретного цветового варианта',
  `price` decimal(10,2) DEFAULT NULL COMMENT 'Цена для конкретного цветового варианта',
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `product_colors`
--

INSERT INTO `product_colors` (`id`, `product_id`, `sku`, `color_name`, `color_code`, `image_path`, `description`, `price`, `is_default`) VALUES
(1, 1, 'IPHONE14CASE', 'Красный', '#ff5252', '/img/products/8 красный.PNG', 'Чехол для iPhone 14 красного цвета. Изготовлен из высококачественного силикона с мягкой подкладкой из микрофибры.', '1990.00', 1),
(2, 1, 'IPHONE14CASE', 'Синий', '#4285f4', '/img/products/8 белый.PNG', 'Чехол для iPhone 14 синего цвета. Защищает от царапин и небольших падений. Тонкий дизайн.', '1990.00', 0),
(3, 1, 'IPHONE14CASE', 'Зеленый', '#4caf50', '/img/products/8 розовое золото.PNG', 'Чехол для iPhone 14 зеленого цвета. Прочное покрытие, устойчивое к отпечаткам пальцев.', '1990.00', 0),
(4, 1, 'IPHONE14CASE', 'Желтый', '#ffeb3b', '/img/products/14 red.jpg', 'Яркий желтый чехол для iPhone 14. Легкий и удобный в использовании.', '1990.00', 0),
(5, 2, 'IPHONE13CASE', 'Красный', '#ff5252', '/img/products/8 красный.PNG', 'Премиум чехол для iPhone 13 красного цвета. Защита от ударов по всему периметру.', '1590.00', 1),
(6, 2, 'IPHONE13CASE', 'Голубой', '#4285f4', '/img/products/8 белый.PNG', 'Голубой чехол для iPhone 13. Повышенная прочность при небольшой толщине.', '1590.00', 0),
(7, 2, 'IPHONE13CASE', 'Розовое золото', '#ffc0cb', '/img/products/8 розовое золото.PNG', 'Элегантный чехол цвета розовое золото для iPhone 13. Идеальная совместимость со всеми функциями.', '1790.00', 0),
(8, 3, 'GALAXYS23CASE', 'Красный', '#ff5252', '/img/products/8 красный.PNG', 'Чехол для Samsung Galaxy S23 красного цвета. Точное соответствие всем портам и кнопкам.', '1490.00', 0),
(9, 3, 'GALAXYS23CASE', 'Белый', '#ffffff', '/img/products/8 белый.PNG', 'Белый чехол для Samsung Galaxy S23. Минималистичный дизайн, максимальная защита.', '1490.00', 1),
(10, 3, 'GALAXYS23CASE', 'Розовое золото', '#ffc0cb', '/img/products/8 розовое золото.PNG', 'Чехол цвета розовое золото для Samsung Galaxy S23. Улучшенная защита камеры.', '1690.00', 0),
(11, 4, 'XIAOMI13CASE', 'Красный', '#ff5252', '/img/products/14 red.jpg', 'Стильный красный чехол для Xiaomi 13. Прочный материал и отличное качество сборки.', '1290.00', 1),
(12, 4, 'XIAOMI13CASE', 'Черный', '#000000', '/img/products/8 розовое золото.PNG', 'Классический черный чехол для Xiaomi 13. Идеально подходит для повседневного использования.', '1290.00', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `product_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `rating` int NOT NULL,
  `text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `name`, `email`, `rating`, `text`, `created_at`) VALUES
(1, 1, 'Александр', 'alex@example.com', 5, 'Отличный смартфон! Камера супер, батарея держит долго.', '2023-06-15 07:23:45'),
(2, 1, 'Мария', 'maria@example.com', 4, 'Хороший телефон за свои деньги, но есть небольшие недочеты в работе интерфейса.', '2023-06-22 11:17:32'),
(3, 2, 'Дмитрий', 'dmitry@example.com', 4, 'Удобные часы, но хотелось бы больше функций для спорта.', '2023-07-05 06:45:18'),
(4, 3, 'Елена', 'elena@example.com', 5, 'Звук просто потрясающий! Очень доволен покупкой!', '2023-07-12 13:33:27'),
(5, 3, 'Иван', 'ivan@example.com', 5, 'Наушники супер! Долго держат заряд и отлично сидят в ушах.', '2023-07-18 08:22:49');

-- --------------------------------------------------------

--
-- Структура таблицы `telegram_verification_codes`
--

CREATE TABLE `telegram_verification_codes` (
  `id` int NOT NULL,
  `chat_id` varchar(50) NOT NULL COMMENT 'ID чата в Telegram',
  `username` varchar(100) DEFAULT NULL COMMENT 'Username пользователя в Telegram',
  `first_name` varchar(100) DEFAULT NULL COMMENT 'Имя пользователя в Telegram',
  `last_name` varchar(100) DEFAULT NULL COMMENT 'Фамилия пользователя в Telegram',
  `code` varchar(10) NOT NULL COMMENT 'Код верификации',
  `expires_at` timestamp NOT NULL COMMENT 'Время истечения кода',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Время создания записи'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Коды верификации для привязки Telegram';

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `fullname` varchar(255) NOT NULL COMMENT 'ФИО пользователя (отчество не обязательно)',
  `email` varchar(255) NOT NULL COMMENT 'Электронная почта пользователя',
  `phone` varchar(20) NOT NULL COMMENT 'Номер телефона пользователя',
  `login` varchar(255) NOT NULL COMMENT 'Логин пользователя для входа в систему',
  `password` varchar(255) NOT NULL COMMENT 'Хешированный пароль пользователя',
  `role` varchar(20) NOT NULL DEFAULT 'user' COMMENT 'Роль пользователя (по умолчанию "user")',
  `telegram_id` varchar(50) DEFAULT NULL COMMENT 'ID пользователя в Telegram',
  `telegram_username` varchar(100) DEFAULT NULL COMMENT 'Username пользователя в Telegram',
  `telegram_verification_code` varchar(10) DEFAULT NULL COMMENT 'Код для подтверждения привязки Telegram',
  `telegram_code_expires` timestamp NULL DEFAULT NULL COMMENT 'Время истечения кода подтверждения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Таблица пользователей интернет-магазина';

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `phone`, `login`, `password`, `role`, `telegram_id`, `telegram_username`, `telegram_verification_code`, `telegram_code_expires`) VALUES
(6, 'Калашников Михаил Дмитриевич', 'kmd2005@list.ru', '+7 (919) 200-07-31', 'Rebiks!123', '$2y$10$nCXidPHY/cxgWdwCy4/jAuqxawbGUjNNXDtcu4WupuZ07c2fVeRfe', 'Администратор', NULL, NULL, NULL, NULL),
(7, 'Калашников Михаил Дмитриевич', 'acv@mail.ru', '+7 (919) 200-07-31', 'kirieshka', '$2y$10$y9CL8zIShMAlJKT9q7Yvfe6qehTcTLHB5KmUM0.q63B//zTeqn54C', 'Администратор', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `added_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `added_at`) VALUES
(3, 2, 10, '2025-05-21 13:14:20'),
(5, 2, 11, '2025-05-21 13:14:41'),
(6, 2, 9, '2025-05-21 13:14:45');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_idx` (`category`),
  ADD KEY `is_new_idx` (`is_new`),
  ADD KEY `is_bestseller_idx` (`is_bestseller`);

--
-- Индексы таблицы `product_colors`
--
ALTER TABLE `product_colors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `sku` (`sku`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id_idx` (`product_id`);

--
-- Индексы таблицы `telegram_verification_codes`
--
ALTER TABLE `telegram_verification_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_chat_id` (`chat_id`),
  ADD UNIQUE KEY `uk_code` (`code`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `login` (`login`),
  ADD KEY `idx_telegram_id` (`telegram_id`),
  ADD KEY `idx_telegram_verification_code` (`telegram_verification_code`);

--
-- Индексы таблицы `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_product` (`user_id`,`product_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `product_colors`
--
ALTER TABLE `product_colors`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `telegram_verification_codes`
--
ALTER TABLE `telegram_verification_codes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
