<?php
// Начинаем сессию
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Подключаем необходимые файлы
require_once 'includes/config/db_config.php';
require_once 'includes/config/db_functions.php';

// Определяем переменные для идентификации пользователя
$session_id = session_id();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// Обработка действий с корзиной
$message = '';
$message_type = '';

// Очистка корзины
if (isset($_POST['clear_cart'])) {
    $result = clearCart($session_id, $user_id);
    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'danger';
}

// Удаление товара из корзины
if (isset($_POST['remove_item'])) {
    $cart_id = (int)$_POST['cart_id'];
    $result = removeFromCart($cart_id, $session_id, $user_id);
    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'danger';
}

// Обновление количества товара
if (isset($_POST['update_quantity'])) {
    $cart_id = (int)$_POST['cart_id'];
    $quantity = (int)$_POST['quantity'];
    $result = updateCartItemQuantity($cart_id, $quantity, $session_id, $user_id);
    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'danger';
}

// Получаем содержимое корзины
$cart_items = getCartItems($session_id, $user_id);

// Рассчитываем итоги корзины
$cart_total = 0;
$total_items = 0;

foreach ($cart_items as $item) {
    $cart_total += $item['subtotal'];
    $total_items += $item['quantity'];
}

// Получаем количество товаров для отображения в шапке
$cart_count = getCartItemCount($session_id, $user_id);

// Задаем заголовок страницы
$page_title = 'Корзина';

// Подключаем дополнительные стили
$additional_styles = '<link rel="stylesheet" href="/css/cart.css">';

// Подключаем шапку сайта
include_once 'includes/header/header.php';
?>

<main class="main-content">
    <div class="container mt-4">
        <h1 class="mb-4">Корзина</h1>
        
        <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if (empty($cart_items)): ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-shopping-cart fa-4x mb-3 text-secondary"></i>
                <h3>Ваша корзина пуста</h3>
                <p class="text-muted">Добавьте товары в корзину, чтобы оформить заказ</p>
                <a href="/catalog.php" class="btn btn-primary mt-3">Перейти в каталог</a>
            </div>
        </div>
        <?php else: ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Товары в корзине (<?php echo $total_items; ?>)</h5>
                        <form method="post" action="">
                            <button type="submit" name="clear_cart" class="btn btn-sm btn-outline-danger" onclick="return confirm('Вы уверены, что хотите очистить корзину?')">
                                <i class="fas fa-trash-alt"></i> Очистить корзину
                            </button>
                        </form>
                    </div>
                    <div class="card-body p-0">
                        <!-- Таблица для десктопов (скрыта на мобильных) -->
                        <div class="table-responsive d-none d-md-block">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Товар</th>
                                        <th>Цена</th>
                                        <th>Количество</th>
                                        <th>Сумма</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cart_items as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div style="width: 60px; height: 60px;" class="flex-shrink-0 me-3">
                                                    <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="img-fluid" style="max-height: 60px; max-width: 60px; object-fit: contain;">
                                                </div>
                                                <div>
                                                    <h6 class="mb-1"><a href="/product.php?id=<?php echo $item['product_id']; ?>" class="text-dark text-decoration-none"><?php echo $item['name']; ?></a></h6>
                                                    <small class="text-muted"><?php echo $item['category']; ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($item['price_discount']): ?>
                                            <div class="d-flex flex-column">
                                                <span class="text-danger fw-bold"><?php echo number_format($item['price_final'], 0, '.', ' '); ?> ₽</span>
                                                <small class="text-muted text-decoration-line-through"><?php echo number_format($item['price_original'], 0, '.', ' '); ?> ₽</small>
                                            </div>
                                            <?php else: ?>
                                            <span class="fw-bold"><?php echo number_format($item['price_final'], 0, '.', ' '); ?> ₽</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <form method="post" action="" class="quantity-form d-flex align-items-center" style="max-width: 120px;">
                                                <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                                <div class="input-group input-group-sm">
                                                    <button type="button" class="btn btn-outline-secondary decrease-quantity" data-form-id="form-<?php echo $item['id']; ?>">-</button>
                                                    <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" max="99" class="form-control text-center" id="form-<?php echo $item['id']; ?>">
                                                    <button type="button" class="btn btn-outline-secondary increase-quantity" data-form-id="form-<?php echo $item['id']; ?>">+</button>
                                                </div>
                                                <button type="submit" name="update_quantity" class="btn btn-sm btn-outline-primary ms-2 update-quantity" style="display: none;">
                                                    <i class="fas fa-sync-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                        <td>
                                            <span class="fw-bold"><?php echo number_format($item['subtotal'], 0, '.', ' '); ?> ₽</span>
                                        </td>
                                        <td>
                                            <form method="post" action="" class="d-inline">
                                                <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                                <button type="submit" name="remove_item" class="btn btn-sm btn-outline-danger" onclick="return confirm('Вы уверены, что хотите удалить этот товар из корзины?')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Карточки для мобильных устройств (отображаются только на мобильных) -->
                        <div class="cart-mobile d-md-none">
                            <?php foreach ($cart_items as $item): ?>
                            <div class="cart-item-card">
                                <div class="row g-0 align-items-center p-3 border-bottom">
                                    <!-- Изображение товара -->
                                    <div class="col-3">
                                        <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" 
                                             class="img-fluid rounded" style="max-width: 80px; object-fit: contain;">
                                    </div>
                                    
                                    <!-- Информация о товаре -->
                                    <div class="col-9">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h6 class="card-title mb-0">
                                                <a href="/product.php?id=<?php echo $item['product_id']; ?>" 
                                                   class="text-dark text-decoration-none"><?php echo $item['name']; ?></a>
                                            </h6>
                                            
                                            <!-- Кнопка удаления -->
                                            <form method="post" action="" class="d-inline ms-2">
                                                <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                                <button type="submit" name="remove_item" class="btn btn-sm btn-outline-danger" 
                                                        onclick="return confirm('Вы уверены, что хотите удалить этот товар из корзины?')">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </div>
                                        
                                        <small class="text-muted d-block mb-2"><?php echo $item['category']; ?></small>
                                        
                                        <!-- Цена -->
                                        <div class="d-flex align-items-center mb-2">
                                            <div class="me-3">
                                                <?php if ($item['price_discount']): ?>
                                                <div class="d-flex flex-column">
                                                    <span class="text-danger fw-bold"><?php echo number_format($item['price_final'], 0, '.', ' '); ?> ₽</span>
                                                    <small class="text-muted text-decoration-line-through"><?php echo number_format($item['price_original'], 0, '.', ' '); ?> ₽</small>
                                                </div>
                                                <?php else: ?>
                                                <span class="fw-bold"><?php echo number_format($item['price_final'], 0, '.', ' '); ?> ₽</span>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <span class="badge bg-secondary">
                                                <?php echo number_format($item['subtotal'], 0, '.', ' '); ?> ₽
                                            </span>
                                        </div>
                                        
                                        <!-- Форма количества -->
                                        <form method="post" action="" class="quantity-form w-100">
                                            <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                            <div class="input-group input-group-sm" style="max-width: 150px;">
                                                <button type="button" class="btn btn-outline-secondary decrease-quantity" 
                                                        data-form-id="mobile-form-<?php echo $item['id']; ?>">-</button>
                                                <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                                       min="1" max="99" class="form-control text-center" 
                                                       id="mobile-form-<?php echo $item['id']; ?>">
                                                <button type="button" class="btn btn-outline-secondary increase-quantity" 
                                                        data-form-id="mobile-form-<?php echo $item['id']; ?>">+</button>
                                                <button type="submit" name="update_quantity" 
                                                        class="btn btn-sm btn-outline-primary update-quantity" style="display: none;">
                                                    <i class="fas fa-sync-alt"></i>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Итого</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Товаров:</span>
                            <span><?php echo $total_items; ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span>Итоговая сумма:</span>
                            <span class="fw-bold"><?php echo number_format($cart_total, 0, '.', ' '); ?> ₽</span>
                        </div>
                        <a href="/checkout.php" class="btn btn-primary w-100 mb-2">Оформить заказ</a>
                        <a href="/catalog.php" class="btn btn-outline-secondary w-100">Продолжить покупки</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Функции для работы с количеством товаров
    const decreaseButtons = document.querySelectorAll('.decrease-quantity');
    const increaseButtons = document.querySelectorAll('.increase-quantity');
    const quantityForms = document.querySelectorAll('.quantity-form');
    
    decreaseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const formId = this.getAttribute('data-form-id');
            const input = document.getElementById(formId);
            const currentValue = parseInt(input.value);
            
            if (currentValue > 1) {
                input.value = currentValue - 1;
                showUpdateButton(input);
            }
        });
    });
    
    increaseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const formId = this.getAttribute('data-form-id');
            const input = document.getElementById(formId);
            const currentValue = parseInt(input.value);
            
            if (currentValue < 99) {
                input.value = currentValue + 1;
                showUpdateButton(input);
            }
        });
    });
    
    quantityForms.forEach(form => {
        const input = form.querySelector('input[type="number"]');
        const updateButton = form.querySelector('.update-quantity');
        
        input.addEventListener('change', function() {
            showUpdateButton(this);
        });
    });
    
    function showUpdateButton(input) {
        const form = input.closest('.quantity-form');
        const updateButton = form.querySelector('.update-quantity');
        updateButton.style.display = 'block';
    }
    
    // Обновление счетчика корзины в шапке сайта
    function updateCartCount(count) {
        const cartCountElements = document.querySelectorAll('.cart-count');
        cartCountElements.forEach(element => {
            element.textContent = count;
        });
    }
    
    // Инициализация счетчика корзины
    updateCartCount(<?php echo $cart_count; ?>);
});
</script>

<?php include_once 'includes/footer/footer.php'; ?> 