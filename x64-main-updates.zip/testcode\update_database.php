<?php
// Подключаем файлы конфигурации
require_once 'includes/config/db_config.php';

// Функция для выполнения SQL-запросов из файла
function executeSQLFile($filename) {
    global $conn;
    
    echo "<h3>Выполнение файла: $filename</h3>";
    
    // Загружаем SQL скрипт
    $sql = file_get_contents($filename);
    
    // Выполняем SQL запросы
    if (mysqli_multi_query($conn, $sql)) {
        echo "<div style='color: green;'>SQL-запросы успешно выполнены.</div>";
        
        // Очищаем результаты, чтобы можно было выполнить следующие запросы
        while (mysqli_more_results($conn) && mysqli_next_result($conn)) {
            // Пропускаем результаты
            $dummyResult = mysqli_use_result($conn);
            if ($dummyResult) {
                mysqli_free_result($dummyResult);
            }
        }
    } else {
        echo "<div style='color: red;'>Ошибка при выполнении SQL-запросов: " . mysqli_error($conn) . "</div>";
    }
    
    echo "<hr>";
}

// Устанавливаем заголовок для правильного отображения кириллицы
header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Обновление базы данных</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            max-width: 800px;
        }
        h1 {
            color: #333;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .error {
            color: red;
            font-weight: bold;
        }
        hr {
            border: 1px solid #ddd;
            margin: 20px 0;
        }
        .button {
            display: inline-block;
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Обновление базы данных</h1>
    
    <?php
    // Выполняем обновление категорий
    executeSQLFile('update_categories.sql');
    
    // Выполняем добавление поля color
    executeSQLFile('add_color_field.sql');
    ?>
    
    <div class="success">Обновление базы данных завершено!</div>
    <a href="admin/index.php?tab=products" class="button">Вернуться в админ-панель</a>
</body>
</html>

<?php
// Закрываем соединение
mysqli_close($conn);
?> 