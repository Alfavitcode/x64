-- Добавляем поля для интеграции с Telegram в таблицу users
ALTER TABLE `users` ADD COLUMN `telegram_id` VARCHAR(50) NULL DEFAULT NULL COMMENT 'ID пользователя в Telegram' AFTER `role`;
ALTER TABLE `users` ADD COLUMN `telegram_username` VARCHAR(100) NULL DEFAULT NULL COMMENT 'Username пользователя в Telegram' AFTER `telegram_id`;
ALTER TABLE `users` ADD COLUMN `telegram_verification_code` VARCHAR(10) NULL DEFAULT NULL COMMENT 'Код для подтверждения привязки Telegram' AFTER `telegram_username`;
ALTER TABLE `users` ADD COLUMN `telegram_code_expires` TIMESTAMP NULL DEFAULT NULL COMMENT 'Время истечения кода подтверждения' AFTER `telegram_verification_code`;

-- Добавляем индекс для быстрого поиска по Telegram ID
ALTER TABLE `users` ADD INDEX `idx_telegram_id` (`telegram_id`);

-- Добавляем индекс для быстрого поиска по коду верификации
ALTER TABLE `users` ADD INDEX `idx_telegram_verification_code` (`telegram_verification_code`); 