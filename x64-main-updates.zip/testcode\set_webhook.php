<?php
// Подключаем файл конфигурации
require_once 'includes/config/telegram_config.php';

// Webhook URL - пользователь должен посетить webhook.site и скопировать свой URL
$webhook_url = isset($_POST['webhook_url']) ? $_POST['webhook_url'] : '';

if (empty($webhook_url)) {
    // Форма для ввода webhook URL
    echo '<h1>Установка вебхука для Telegram бота</h1>';
    echo '<p>Для получения временного URL для тестирования, посетите <a href="https://webhook.site/" target="_blank">webhook.site</a> и скопируйте ваш уникальный URL.</p>';
    echo '<form method="post">';
    echo '<label for="webhook_url">URL вебхука:</label><br>';
    echo '<input type="text" id="webhook_url" name="webhook_url" style="width: 500px;" placeholder="Например: https://webhook.site/your-unique-id"><br><br>';
    echo '<input type="submit" value="Установить вебхук">';
    echo '</form>';
    exit;
}

// Формируем URL для запроса
$url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/setWebhook?url=" . $webhook_url;

// Отправляем запрос
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);

// Декодируем результат
$response = json_decode($result, true);

// Выводим результат
echo "<h1>Результат установки вебхука</h1>";
echo "<pre>";
print_r($response);
echo "</pre>";

// Обновляем конфигурацию
if ($response['ok']) {
    echo "<p>Webhook успешно установлен на URL: " . $webhook_url . "</p>";
    echo "<p>Теперь обновите TELEGRAM_WEBHOOK_URL в файле includes/config/telegram_config.php</p>";
    
    // Форма для обновления конфигурационного файла
    echo '<form method="post" action="update_config.php">';
    echo '<input type="hidden" name="webhook_url" value="' . htmlspecialchars($webhook_url) . '">';
    echo '<input type="submit" value="Обновить конфигурационный файл">';
    echo '</form>';
    
    // Создаем файл update_config.php, если он еще не существует
    if (!file_exists('update_config.php')) {
        $update_config_content = '<?php
// Обновляем конфигурационный файл
if (isset($_POST["webhook_url"])) {
    $webhook_url = $_POST["webhook_url"];
    $config_file = "includes/config/telegram_config.php";
    $config_content = file_get_contents($config_file);
    $config_content = preg_replace(
        \'/define\\(\\\'TELEGRAM_WEBHOOK_URL\\\',\\s*\\\'.*\\\'\\);\'/i\',
        "define(\'TELEGRAM_WEBHOOK_URL\', \'" . $webhook_url . "\');",
        $config_content
    );
    file_put_contents($config_file, $config_content);
    echo "<p>Конфигурационный файл успешно обновлен!</p>";
    echo "<p><a href=\"test_bot.php\">Перейти к тестированию бота</a></p>";
}
?>';
        file_put_contents('update_config.php', $update_config_content);
    }
}

// Добавляем ссылку для получения информации о вебхуке
echo "<p><a href='https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/getWebhookInfo'>Получить информацию о текущем вебхуке</a></p>";
?> 