<?php
// Подключаем файлы конфигурации
require_once 'includes/config/telegram_config.php';

// Функция для отправки запроса к API Telegram
function sendTelegramRequest($method, $params = []) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/" . $method;
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $result = curl_exec($ch);
    
    if (curl_errno($ch)) {
        echo "Ошибка cURL: " . curl_error($ch);
        return false;
    }
    
    curl_close($ch);
    
    return json_decode($result, true);
}

// Получаем информацию о боте
$botInfo = sendTelegramRequest('getMe');

// Выводим результат
echo "<h1>Информация о боте</h1>";
echo "<pre>";
print_r($botInfo);
echo "</pre>";

// Получаем информацию о текущем вебхуке
$webhookInfo = sendTelegramRequest('getWebhookInfo');

// Выводим результат
echo "<h1>Информация о вебхуке</h1>";
echo "<pre>";
print_r($webhookInfo);
echo "</pre>";

// Форма для установки вебхука
echo "<h1>Установка вебхука</h1>";
echo "<form method='post'>";
echo "<label for='webhook_url'>URL вебхука:</label><br>";
echo "<input type='text' id='webhook_url' name='webhook_url' value='" . TELEGRAM_WEBHOOK_URL . "' style='width: 500px;'><br><br>";
echo "<input type='submit' name='set_webhook' value='Установить вебхук'>";
echo "</form>";

// Обработка формы
if (isset($_POST['set_webhook'])) {
    $webhookUrl = $_POST['webhook_url'];
    
    // Устанавливаем вебхук
    $setWebhook = sendTelegramRequest('setWebhook', [
        'url' => $webhookUrl,
        'drop_pending_updates' => true
    ]);
    
    // Выводим результат
    echo "<h2>Результат установки вебхука</h2>";
    echo "<pre>";
    print_r($setWebhook);
    echo "</pre>";
}

// Форма для удаления вебхука
echo "<h1>Удаление вебхука</h1>";
echo "<form method='post'>";
echo "<input type='submit' name='delete_webhook' value='Удалить вебхук'>";
echo "</form>";

// Обработка формы
if (isset($_POST['delete_webhook'])) {
    // Удаляем вебхук
    $deleteWebhook = sendTelegramRequest('deleteWebhook');
    
    // Выводим результат
    echo "<h2>Результат удаления вебхука</h2>";
    echo "<pre>";
    print_r($deleteWebhook);
    echo "</pre>";
}

// Форма для отправки тестового сообщения
echo "<h1>Отправка тестового сообщения</h1>";
echo "<form method='post'>";
echo "<label for='chat_id'>ID чата:</label><br>";
echo "<input type='text' id='chat_id' name='chat_id' placeholder='Введите ID чата'><br><br>";
echo "<label for='message'>Сообщение:</label><br>";
echo "<textarea id='message' name='message' rows='4' cols='50'>Тестовое сообщение от бота</textarea><br><br>";
echo "<input type='submit' name='send_message' value='Отправить сообщение'>";
echo "</form>";

// Обработка формы
if (isset($_POST['send_message'])) {
    $chatId = $_POST['chat_id'];
    $message = $_POST['message'];
    
    // Отправляем сообщение
    $sendMessage = sendTelegramRequest('sendMessage', [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ]);
    
    // Выводим результат
    echo "<h2>Результат отправки сообщения</h2>";
    echo "<pre>";
    print_r($sendMessage);
    echo "</pre>";
}
?> 